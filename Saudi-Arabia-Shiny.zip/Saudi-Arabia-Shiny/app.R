

setwd("~/Desktop/shiny/Saudi-Arabia-Shiny")
library(maps)
library(leaflet)
library(dplyr)
library(shiny)
library(rgeoboundaries)
library(rnaturalearth)
library(sf)
library(SpatialEpi)
library(sp)
library(INLA)
library(spdep)


######### Get the map of Saudi Arabia ##############
map <- ne_states(country = "Saudi Arabia", returnclass = "sf")
map$name[5] <- "Asir"
map <- st_set_crs(map, 4326)
map <- map %>% select(name, geometry)
plot(map)

######### Get the data of the diseases in Saudi Arabia ##############
data <- read.csv("data/Diseases.csv", header = TRUE)
data <- data[order(data$name),]
head(data)

######### Add the data to the map ##############
map <- map %>%
  left_join(data, by = "name")




######## Expected ########################


map$E <- expected(population = map$Population, cases = map$Diabetes, n.strata = 1)



######## INLA ########################

map <- as(map, "Spatial")
rownames(map@data) <- map@data$name


######## INLA ########################

nb <- poly2nb(map)
nb2INLA("map.adj", nb)
g <- inla.read.graph(filename = "map.adj")
map$re_u <- 1:nrow(map@data)
map$re_v <- 1:nrow(map@data)




# for Diabetes

formula <- map@data$Diabetes ~ 1 + f(re_u, model = "besag", graph = g, scale.model = TRUE) + f(re_v, model = "iid")

res <- inla(formula, family = "poisson", data = map@data, E = E, control.predictor = list(compute = TRUE))

map$RR <- res$summary.fitted.values[, "mean"]



l <- leaflet(map) %>% addTiles()
pal <- colorNumeric(palette = "YlOrRd", domain = map$RR)

l %>% addPolygons(color = "grey", weight = 1, fillColor = ~pal(RR), fillOpacity = 0.5) %>%
  addLegend(pal = pal, values = ~RR, opacity = 0.5, title = "RR", position = "bottomright")






######### UI ##############
ui <- fluidPage(
  tags$head(
    tags$style(HTML("
      .title-panel-custom {
        color: gray;
        font-size: 24px;
        font-weight: bold;
      }
      .sidebar-label-custom {
        margin-top: 20px;
      }
      .sidebar-content {
        display: flex;
        flex-direction: column;
        height: 100%;
      }
      .select-input-container {
        flex-grow: 1;
      }
      .result-container {
        margin-top: auto;
      }
    "))
  ),
  titlePanel(
    title = div("Visualization of Diseases in Saudi Arabia", class = "title-panel-custom")
  ),
  sidebarLayout(
    sidebarPanel(
      tags$div(class = "sidebar-content",
               tags$div(class = "select-input-container",
                        tags$p("Please select a disease to visualize its spatial distribution on the map."),
                        tags$div(class = "sidebar-label-custom",
                                 selectInput("disease", "Select Disease:", 
                                             choices = c("Cardiovascular", "Cancer", "Diabetes", "Hypertension", "Population"),
                                             selected = "Cancer")
                        )
               ),
               tags$div(class = "result-container",
                        tags$h3("Result"),
                        textOutput("report")
               )
      )
    ),
    mainPanel(
      leafletOutput("mymap")
    )
  )
)

######### SERVER ##############
server <- function(input, output, session) {
  
  output$mymap <- renderLeaflet({
    disease_col <- input$disease
    pal <- colorNumeric(palette = "YlOrRd", domain = map[[disease_col]])
    
    leaflet(map) %>% 
      addTiles() %>% 
      addPolygons(
        color = "grey", 
        weight = 1, 
        fillColor = ~pal(map[[disease_col]]), 
        fillOpacity = 0.5,
        highlight = highlightOptions(
          weight = 3,
          color = "#666",
          fillOpacity = 0.7,
          bringToFront = TRUE),
        label = ~paste(name, disease_col, ":", map[[disease_col]])
      ) %>%
      addLegend(
        pal = pal, 
        values = map[[disease_col]], 
        opacity = 0.5, 
        title = disease_col, 
        position = "bottomright"
      )
  })
  
  output$report <- renderText({
    disease_col <- input$disease
    highest_risk_region <- map$name[which.max(map[[disease_col]])]
    highest_risk_value <- max(map[[disease_col]], na.rm = TRUE)
    
    paste("The highest risk of", disease_col, "is in", highest_risk_region, "with a value of", highest_risk_value)
  })
}

shinyApp(ui, server)


shinyApp(ui, server)
